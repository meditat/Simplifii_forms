package com.example.simplifiiform;

import android.content.Context;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.ramotion.fluidslider.FluidSlider;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {

    private static String TAG = "Something";
    static String data = "";
    static List<Model> models;
    LinearLayout linearLayout;

    int TEXT_ID = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        models = new ArrayList<>();
        linearLayout = findViewById(R.id.my_layout);
        FetchData fetchData = new FetchData(this, linearLayout);
        fetchData.execute();
    }


    public class FetchData extends AsyncTask<Void, Void, Void> {

        Context context;
        LinearLayout linearLayout;

        FetchData(Context context, LinearLayout linearLayout) {
            this.context = context;
            this.linearLayout = linearLayout;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            try {
                URL apiUrl = new URL("https://ca.platform.simplifii.xyz/api/v1/static/assignment2");
                HttpsURLConnection connection = (HttpsURLConnection) apiUrl.openConnection();
                InputStream inputStream = connection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                String line = "";
                while (line != null) {
                    line = reader.readLine();
                    data = data + line;
                }

                JSONObject object = new JSONObject(data);
                JSONObject response = (JSONObject) object.get("response");
                JSONArray jsonArray = response.getJSONArray("data");

                for (int i = 0; i < jsonArray.length(); i++) {

                    JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                    Model model = new Model();
                    if (jsonObject.get("type").toString().equals("range")) {
                        model.setType(jsonObject.get("type").toString());
                        model.setLabel(jsonObject.get("label").toString());
                        model.setName(jsonObject.get("name").toString());
                        model.setMin(Integer.parseInt(jsonObject.get("min").toString()));
                        model.setMax(Integer.parseInt(jsonObject.get("max").toString()));
                        model.setInterval(Integer.parseInt(jsonObject.get("intervals").toString()));
                    }
                    if (jsonObject.get("type").toString().equals("input")) {
                        model.setType(jsonObject.get("type").toString());
                        model.setLabel(jsonObject.get("label").toString());
                        model.setName(jsonObject.get("name").toString());
                        model.setInputType(jsonObject.get("inputType").toString());
                        JSONArray jsonArray1 = jsonObject.getJSONArray("validations");
                        JSONObject jsonObject1 = (JSONObject) jsonArray1.get(0);
                        model.setValidationName(jsonObject1.get("name").toString());
                        model.setValidationMsg(jsonObject1.get("message").toString());
                    }
                    if (jsonObject.get("type").toString().equals("button")) {
                        model.setType(jsonObject.get("type").toString());
                        model.setAction(jsonObject.get("action").toString());
                        model.setLabel(jsonObject.get("label").toString());
                        JSONObject obj = jsonObject.getJSONObject("api");
                        model.setApiUri(obj.getString("uri"));
                        Log.d("wtf", "doInBackground: " + model.getApiUri());
                        model.setApiMethod(obj.getString("method"));
                        model.setAuthEnabled(Boolean.parseBoolean(obj.getString("authEnabled")));
                    }

                    Log.d(TAG, "doInBackground: " + model.getType());

                    models.add(model);
                }


            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            if (!models.isEmpty()) {
                for (int i = 0; i < models.size(); i++) {
                    Model model = models.get(i);
                    if (model.getType().equals("range")){
                        FluidSlider fluidSlider = new FluidSlider(context);
                        fluidSlider.setStartText(String.valueOf(model.getMin()));
                        fluidSlider.setEndText(String.valueOf(model.getMax()));

                        LinearLayout.LayoutParams lp  =new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT);
                        fluidSlider.setLayoutParams(lp);
                        linearLayout.addView(fluidSlider);
                    }
                }

            }
        }
    }
}

